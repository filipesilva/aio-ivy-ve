export class Item {
  id: number;
  name: string;
}

