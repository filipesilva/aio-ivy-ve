import { ItemDirective } from './item.directive';

describe('ItemDirective', () => {
  it('should create an instance', () => {
    const directive = new ItemDirective();
    expect(directive).toBeTruthy();
  });
});
